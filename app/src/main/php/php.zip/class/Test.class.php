<?php

class Test extends DB
{
    // Get default data.
    function get_data()
    {
        $response = [];
        $response['success'] = 1;
        $response['message'] = "Connected to the database.";

        return $response;
    }
}

?>