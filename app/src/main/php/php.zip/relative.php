<?php

// Configuration and create connection.
include_once("class/DB.class.php");
include_once("class/Relative.class.php");

$relative = new Relative();
$relative->open();

$response = $relative->get_data();
$relative->close();

header("Content-Type: application/json; charset=utf-8");
echo json_encode($response);

?>